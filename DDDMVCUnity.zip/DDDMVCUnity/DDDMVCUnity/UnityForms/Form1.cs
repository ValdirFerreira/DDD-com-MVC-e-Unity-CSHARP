﻿/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using ApplicationCoffee.Interfaces;
using Domain.Entities;
using Domain.Validations.ValidationsGeneric;
using Microsoft.Practices.Unity;
using System;
using System.Windows.Forms;

namespace UnityForms
{
    public partial class Form1 : Form
    {

        IProdutoApp _ProdutoApp;

        public Form1(IUnityContainer container, IProdutoApp ProdutoApp)
        {
            _ProdutoApp = ProdutoApp;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Produto Prod = new Produto
                {
                    Id = 0,
                    Nome = txtNome.Text,
                    Preco = !string.IsNullOrEmpty(txtPreco.Text) ? Convert.ToDecimal(txtPreco.Text) : 0
                };

                _ProdutoApp.Adicionar(Prod);

                MensagemSucesso();
            }
            catch (ValidException Ex)
            {
                var Erro = Ex.Erros;

                string Erros = string.Empty;

                foreach (var item in Erro)
                {
                    Erros += item.Mensagem.ToString() + "\n";
                }

                MessageBox.Show(Erros, "Erro");
            }

        }


        public void MensagemSucesso()
        {
            txtNome.Text = string.Empty;
            txtPreco.Text = string.Empty;
            MessageBox.Show("Cadastrado com Sucesso");
        }
    }
}
