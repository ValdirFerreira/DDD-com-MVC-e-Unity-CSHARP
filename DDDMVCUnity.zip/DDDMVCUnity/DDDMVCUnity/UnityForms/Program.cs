﻿/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/
using ApplicationCoffee.AppProduto.ApplicationForms;
using ApplicationCoffee.Interfaces;
using Domain.Interface.Generic;
using Domain.Interface.InterfaceProduto;
using Infrastructure.Repository;
using Infrastructure.RepositoryProduto;
using Microsoft.Practices.Unity;
using System;
using System.Windows.Forms;

namespace UnityForms
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());


            UnityContainer container = new UnityContainer();
            container.RegisterType(typeof(InterfaceGeneric<>), typeof(RepositoryGeneric<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoRepository), typeof(ProdutoRepository), (new HierarchicalLifetimeManager()));
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<Produto, Produto>(new HierarchicalLifetimeManager());
            //container.RegisterType<ViolacaoValid, ViolacaoValid>(new HierarchicalLifetimeManager());
            //container.RegisterType<ValidException, ValidException>(new HierarchicalLifetimeManager());
            //container.RegisterType(typeof(ValidRegraException<>), typeof(ValidRegraException<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoApp), typeof(ApplicationProdutoForm), (new HierarchicalLifetimeManager()));
            // container.RegisterType(typeof(IProdutoApp), typeof(IApplicationGeneric<>), (new HierarchicalLifetimeManager()));
            //container.RegisterType(typeof(ProdutoRepository), typeof(RepositoryGeneric<Produto>), (new HierarchicalLifetimeManager()));

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(container, new ApplicationProdutoForm()));

        }
    }
}
