﻿/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/
using ApplicationCoffee.AppProduto;
using ApplicationCoffee.Interfaces;
using Domain.Interface.Generic;
using Domain.Interface.InterfaceProduto;
using Infrastructure.Repository;
using Infrastructure.RepositoryProduto;
using Microsoft.Practices.Unity;

namespace UnityForms
{
    public class RegistrationModule
    {
        IUnityContainer container = null;
        public RegistrationModule(IUnityContainer container)
        {
            this.container = container;
        }

        public void Initialize()
        {
            container.RegisterType(typeof(InterfaceGeneric<>), typeof(RepositoryGeneric<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoRepository), typeof(ProdutoRepository), (new HierarchicalLifetimeManager()));
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<Produto, Produto>(new HierarchicalLifetimeManager());
            //container.RegisterType<ViolacaoValid, ViolacaoValid>(new HierarchicalLifetimeManager());
            //container.RegisterType<ValidException, ValidException>(new HierarchicalLifetimeManager());
            //container.RegisterType(typeof(ValidRegraException<>), typeof(ValidRegraException<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoApp), typeof(ApplicationProduto), (new HierarchicalLifetimeManager()));
            // container.RegisterType(typeof(IProdutoApp), typeof(IApplicationGeneric<>), (new HierarchicalLifetimeManager()));
            //container.RegisterType(typeof(ProdutoRepository), typeof(RepositoryGeneric<Produto>), (new HierarchicalLifetimeManager()));

        }
    }
}
