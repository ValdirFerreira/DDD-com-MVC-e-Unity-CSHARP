﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.Validations.ObjetosGeneric;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Domain.Validations.ValidationsGeneric
{
    public class ValidException : Exception
    {

        protected IList<ViolacaoValid> _erros = new List<ViolacaoValid>();
        public readonly Expression<Func<object, object>> _objeto = x => x;

        public IList<ViolacaoValid> Erros { get { return _erros; } }

        protected void AdicionarErroAoModelo(string mensagem)
        {
            _erros.Add(new ViolacaoValid { Propriedade = _objeto, Mensagem = mensagem });
        }
    }
}
