﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.Validations.ObjetosGeneric;
using System;
using System.Linq.Expressions;

namespace Domain.Validations.ValidationsGeneric
{
    public class ValidRegraException<T> : ValidException
    {
        internal void AdicionarErroPara<TPropriedade>(Expression<Func<T, TPropriedade>> propriedade, string mensagem)
        {
            _erros.Add(new ViolacaoValid { Propriedade = propriedade, Mensagem = mensagem });
        }
    }
}
