﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using System.Linq.Expressions;

namespace Domain.Validations.ObjetosGeneric
{
    public class ViolacaoValid
    {
        public LambdaExpression Propriedade { get; internal set; }
        public string Mensagem { get; internal set; }
    }
}
