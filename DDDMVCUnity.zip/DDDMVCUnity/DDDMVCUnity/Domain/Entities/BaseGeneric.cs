﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/


namespace Domain.Entities
{
    public class BaseGeneric
    {
        public int Id { get; set; }

        public string Nome { get; set; }
    }
}
