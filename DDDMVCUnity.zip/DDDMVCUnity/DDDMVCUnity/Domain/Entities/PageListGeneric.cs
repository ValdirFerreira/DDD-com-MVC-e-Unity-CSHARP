﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using System;
using System.Collections.Generic;

namespace Domain.Entities
{
    public class PageListGeneric<T>
    {
        public List<T> Content { get; set; }
        public Int32 CurrentPage { get; set; }
        public Int32 PageSize { get; set; }
        public int Total { get; set; }

        public int TotalPages
        {
            get { return (int)Math.Ceiling((decimal)Total / PageSize); }
        }
    }
}
