﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.ResourceMensagens;
using Domain.Validations.ValidationsGeneric;

namespace Domain.Entities
{
    public class Produto : BaseGeneric
    {
        public Produto()
        {

        }
        public decimal Preco { get; set; }

        public Produto(int id, string nome, decimal preco)
        {
            ValidarProduto(nome);

            this.Id = id;
            this.Nome = nome;
            this.Preco = preco;
        }

        public void ValidarProduto(string Nome)
        {
            var rValidException = new ValidRegraException<Produto>();

            if (string.IsNullOrWhiteSpace(Nome))
                rValidException.AdicionarErroPara(x => x.Nome, string.Format("{0}: {1}", "Nome do produto", Resource.CampoNaoInformado));

            if (Nome.Length > 150)
                rValidException.AdicionarErroPara(x => x.Nome, string.Format("{0}: {1}", Resource.CampoTamanhoMaximo, 150));

            if (rValidException.Erros.Count > 0)
                throw rValidException;
        }

    }
}
