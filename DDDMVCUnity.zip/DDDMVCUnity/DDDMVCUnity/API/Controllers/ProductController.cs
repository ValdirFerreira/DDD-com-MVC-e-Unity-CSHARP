﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using ApplicationCoffee.Interfaces;
using Domain.Entities;
using Domain.Validations.ValidationsGeneric;
using System.Web.Http;

namespace API.Controllers
{
    public class ProductController : ApiController
    {
        IProdutoApp _ProdutoApp;

        public ProductController(IProdutoApp ProdutoApp)
        {
            _ProdutoApp = ProdutoApp;
        }

        public void Cadastro(Produto value)
        {
            try
            {
                var prod = new Produto { Nome = value.Nome, Preco = value.Preco };

                _ProdutoApp.Adicionar(prod);
            }
            catch (ValidException Ex)
            {
                var error = Ex.Erros;
            }

        }

    }
}
