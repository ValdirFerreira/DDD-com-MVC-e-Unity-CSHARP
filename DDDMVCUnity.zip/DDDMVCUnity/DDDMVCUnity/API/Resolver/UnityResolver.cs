﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using ApplicationCoffee.AppProduto;
using ApplicationCoffee.Interfaces;
using Domain.Interface.Generic;
using Domain.Interface.InterfaceProduto;
using Infrastructure.Repository;
using Infrastructure.RepositoryProduto;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Web.Http.Dependencies;


namespace API.Resolver
{
    public class UnityResolver : IDependencyResolver
    {
        protected IUnityContainer Container;

        public UnityResolver(IUnityContainer container)
        {
            if (container == null)
            {
                throw new ArgumentNullException("container");
            }

            container.RegisterType(typeof(InterfaceGeneric<>), typeof(RepositoryGeneric<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoRepository), typeof(ProdutoRepository), (new HierarchicalLifetimeManager()));
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<BaseGeneric, BaseGeneric>(new HierarchicalLifetimeManager());
            //container.RegisterType<Produto, Produto>(new HierarchicalLifetimeManager());
            //container.RegisterType<ViolacaoValid, ViolacaoValid>(new HierarchicalLifetimeManager());
            //container.RegisterType<ValidException, ValidException>(new HierarchicalLifetimeManager());
            //container.RegisterType(typeof(ValidRegraException<>), typeof(ValidRegraException<>), (new HierarchicalLifetimeManager()));
            container.RegisterType(typeof(IProdutoApp), typeof(ApplicationProduto), (new HierarchicalLifetimeManager()));
           // container.RegisterType(typeof(IProdutoApp), typeof(IApplicationGeneric<>), (new HierarchicalLifetimeManager()));
            //container.RegisterType(typeof(ProdutoRepository), typeof(RepositoryGeneric<Produto>), (new HierarchicalLifetimeManager()));

            Container = container;
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return Container.Resolve(serviceType);
            }
            catch (ResolutionFailedException)
            {
                return null;
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return Container.ResolveAll(serviceType);
            }
            catch (ResolutionFailedException)
            {
                return new List<object>();
            }
        }

        public IDependencyScope BeginScope()
        {
            IUnityContainer child = Container.CreateChildContainer();
            return new UnityResolver(child);
        }

        public void Dispose()
        {
            Container.Dispose();
        }
    }
}