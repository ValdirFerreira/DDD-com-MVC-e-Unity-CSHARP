﻿

/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/
using Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace Infrastructure.Mapping
{
    public class ProdutoMap : EntityTypeConfiguration<Produto>
    {
        public ProdutoMap()
        {
            HasKey(t => t.Id);
            // Properties
            Property(t => t.Nome)
                .HasMaxLength(160)
                .IsRequired();
        }
    }
}
