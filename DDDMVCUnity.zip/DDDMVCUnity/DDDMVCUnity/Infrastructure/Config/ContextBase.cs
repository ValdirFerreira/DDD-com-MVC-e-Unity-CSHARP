﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.Entities;
using Infrastructure.Mapping;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Infrastructure.Config
{
    public class ContextBase : DbContext
    {

        public ContextBase()
            : base("ConectionString")
        {
            // Database.SetInitializer(new Inicializacoes());
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            base.OnModelCreating(modelBuilder);

            // Incluir mapeamento do Objeto aqui
            modelBuilder.Configurations.Add(new ProdutoMap());
        }
        // Incluir
        public DbSet<Produto> ObjetoProduto { get; set; }
    }
}
