﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.Interface.Generic;
using Infrastructure.Config;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace Infrastructure.Repository
{
    public class RepositoryGeneric<T> : InterfaceGeneric<T>, IDisposable where T : class
    {

        #region Configurações do repositorio Generico

        private readonly ContextBase Contexto;
        public RepositoryGeneric()
        {
            Contexto = new ContextBase();
        }

        ~RepositoryGeneric()
        {
            Dispose(false);
        }

        #endregion

        /// <summary>
        /// Método para inclusão com Objeto
        /// </summary>
        /// <param name="Entity"></param>
        public virtual void Adicionar(T Entity)
        {
            Contexto.Set<T>().Add(Entity);
            Contexto.SaveChanges();
        }

        /// <summary>
        /// Método para atualização  com Objeto
        /// </summary>
        /// <param name="Entity"></param>
        public virtual void Atualizar(T Entity)
        {
            Contexto.Entry(Entity).State = EntityState.Modified;
            Contexto.SaveChanges();

        }

        /// <summary>
        /// Método para Exclusão com Objeto
        /// </summary>
        /// <param name="Entity"></param>
        public virtual void Deletar(T Entity)
        {
            Contexto.Set<T>().Remove(Entity);
            Contexto.SaveChanges();
        }

        /// <summary>
        /// Método para obter um registro por ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Obter(int id)
        {
            return Contexto.Set<T>().Find(id);
        }

        /// <summary>
        /// Método procura registro com referencias de parametros e exppressoes da consulta
        /// </summary>
        /// <param name="predicado"></param>
        /// <param name="@somenteLeitura"></param>
        /// <returns></returns>
        public virtual IEnumerable<T> Procurar(Expression<Func<T, bool>> predicado, bool @somenteLeitura = false)
        {
            return @somenteLeitura ? Contexto.Set<T>().AsNoTracking().ToList()
                                   : Contexto.Set<T>().ToList();
        }

        /// <summary>
        /// Retornar toroas os registros ( Select * )
        /// </summary>
        /// <param name="@somenteLeitura"></param>
        /// <returns></returns>
        public virtual IEnumerable<T> Todos(bool @somenteLeitura = false)
        {
            return @somenteLeitura ? Contexto.Set<T>().AsNoTracking().ToList()
                                  : Contexto.Set<T>().ToList();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!disposing) return;
            if (Contexto == null) return;
            Contexto.Dispose();

        }
    }
}
