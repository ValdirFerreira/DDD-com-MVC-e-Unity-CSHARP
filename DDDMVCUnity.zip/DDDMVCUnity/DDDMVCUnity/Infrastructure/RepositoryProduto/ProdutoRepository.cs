﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/
using Domain.Entities;
using Domain.Interface.InterfaceProduto;
using Infrastructure.Repository;

namespace Infrastructure.RepositoryProduto
{
    public class ProdutoRepository : RepositoryGeneric<Produto>, IProdutoRepository
    {
    }
}