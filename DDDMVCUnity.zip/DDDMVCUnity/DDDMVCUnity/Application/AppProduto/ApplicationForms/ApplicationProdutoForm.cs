﻿using ApplicationCoffee.Interfaces;
using Domain.Entities;
using Domain.Interface.InterfaceProduto;
using Infrastructure.RepositoryProduto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationCoffee.AppProduto.ApplicationForms
{
    public class ApplicationProdutoForm : IProdutoApp
    {
        // private readonly 
        IProdutoRepository _IProdutoRepository;

        public ApplicationProdutoForm()
        {
            _IProdutoRepository = new ProdutoRepository();
        }

        public Produto Get(int id, bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Obter(id);
        }

        public IEnumerable<Produto> Todos(bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Todos(@somenteLeitura);
        }

        public IEnumerable<Produto> Procurar(Expression<Func<Produto, bool>> predicate, bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Procurar(predicate, somenteLeitura);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Produto> GetTopSellingProdutos(int count)
        {
            throw new NotImplementedException();
        }

        public void Adicionar(Produto Entity)
        {
            //BeginTransaction();

            _IProdutoRepository.Adicionar(Entity);

            //  Commit();
        }

        public void Atualizar(Produto Entity)
        {
            // BeginTransaction();
            _IProdutoRepository.Atualizar(Entity);

            //  Commit();
        }

        public void Deletar(Produto Entity)
        {
            // BeginTransaction();
            _IProdutoRepository.Deletar(Entity);

            // Commit();
        }

        public Produto Obter(int id)
        {
            return _IProdutoRepository.Obter(id);
        }
    }
}
