﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using ApplicationCoffee.Interfaces;
using Domain.Entities;
using Domain.Interface.InterfaceProduto;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace ApplicationCoffee.AppProduto
{
    public class ApplicationProduto : IProdutoApp
    {
        // private readonly 
        IProdutoRepository _IProdutoRepository;

        public ApplicationProduto( IProdutoRepository _ProdutoRepository)
        {
            _IProdutoRepository = _ProdutoRepository;
        }

        public Produto Get(int id, bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Obter(id);
        }

        public IEnumerable<Produto> Todos(bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Todos(@somenteLeitura);
        }

        public IEnumerable<Produto> Procurar(Expression<Func<Produto, bool>> predicate, bool @somenteLeitura = false)
        {
            return _IProdutoRepository.Procurar(predicate, somenteLeitura);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Produto> GetTopSellingProdutos(int count)
        {
            throw new NotImplementedException();
        }

        public void Adicionar(Produto Entity)
        {
            //BeginTransaction();

            _IProdutoRepository.Adicionar(Entity);

            //  Commit();
        }

        public void Atualizar(Produto Entity)
        {
            // BeginTransaction();
            _IProdutoRepository.Atualizar(Entity);

            //  Commit();
        }

        public void Deletar(Produto Entity)
        {
            // BeginTransaction();
            _IProdutoRepository.Deletar(Entity);

            // Commit();
        }

        public Produto Obter(int id)
        {
            return _IProdutoRepository.Obter(id);
        }
    }
}
