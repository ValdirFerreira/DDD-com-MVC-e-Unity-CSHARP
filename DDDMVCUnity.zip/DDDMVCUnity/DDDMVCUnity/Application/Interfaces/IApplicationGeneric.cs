﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace ApplicationCoffee.Interfaces
{
    public interface IApplicationGeneric<T> where T : class
    {
        void Adicionar(T Entity);
        void Atualizar(T Entity);
        void Deletar(T Entity);
        T Obter(int id);
        IEnumerable<T> Todos(bool @somenteLeitura = false);
        IEnumerable<T> Procurar(Expression<Func<T, bool>> predicado, bool @somenteLeitura = false);
    }
}
