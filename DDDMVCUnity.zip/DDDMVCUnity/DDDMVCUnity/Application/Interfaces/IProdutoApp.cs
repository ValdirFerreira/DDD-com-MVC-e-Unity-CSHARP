﻿
/*
Projeto DDDMVCUnity 
Desenho da arquitetura por : Valdir Ferreira
Criado por : Valdir Ferreira
Desenvolvido por : Valdir Ferreira
Data de Criação  : 
*/

using Domain.Entities;

namespace ApplicationCoffee.Interfaces
{
    public interface IProdutoApp : IApplicationGeneric<Produto>
    {
        //IEnumerable<Produto> GetTopSellingProdutos(int count);
    }
}
